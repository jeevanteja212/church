<?php
// churchThemes Admin Interface: Setup, Pages, Machine

function churchthemes_add_admin() {

    global $query_string;
    
    $options =  get_option('church_template');      
    $themename =  get_option('church_themename');      
    $shortname =  get_option('church_shortname');      

    $page_advertising = false;
    $page_image_resizing = false;
    $page_nav = false;
    
    foreach  ($options as $value){
        if($value['page'] == 'advertising') $page_advertising = true; 
        if($value['page'] == 'image') $page_resizing = true;
        if($value['page'] == 'nav') $page_nav = true;
    }

    if ( $_GET['page'] == 'churchthemes_home' ||
         $_GET['page'] == 'churchthemes_advertising' ||
         $_GET['page'] == 'churchthemes_uploader' ||
         $_GET['page'] == 'churchthemes_image') 
    {
           
        if ( 'save' == $_REQUEST['action'] ) {
    
                foreach ($options as $key => $value) {
                
                    
                    $live_page = $_GET['page'];
                    $current_page = 'churchthemes_'.$value['page'];
                    
                    if($current_page == 'churchthemes_'){$current_page = 'churchthemes_home';}

                    if($current_page === $live_page){
                                         
                        if ( is_array($value['type'])) {
                        
                            foreach($value['type'] as $array){
                                if($array['type'] == 'text'){
                                $id = $array['id']; 
                                update_option( $id, $_REQUEST[ $id ]);
                                }
                            }                 
                        }
                     
                        elseif($value['type'] == 'checkbox'){
                             if(isset( $_REQUEST[ $value['id'] ])){update_option( $value['id'], $_REQUEST[ $value['id'] ] );} else { update_option( $value['id'] , 'false' ); }
                        } 
                        

                        elseif($value['type'] == 'select'){
                             if(isset( $_REQUEST[ $value['id'] ])){update_option( $value['id'], htmlentities($_REQUEST[ $value['id'] ] ));} else { delete_option( htmlentities($value['id'] )); }
                               
                        } 
                        elseif($value['type'] != 'multicheck'){
                             if(isset( $_REQUEST[ $value['id'] ])){update_option( $value['id'], $_REQUEST[ $value['id'] ] );} else { delete_option( $value['id'] ); }
                               
                        }
                        else  // Multicheck
                        {
                            foreach($value['options'] as $mc_key => $mc_value){
                                $up_opt = $value['id'].'_'.$mc_key;
                                 if(isset( $_REQUEST[ $up_opt ])){update_option( $up_opt, $_REQUEST[ $up_opt ] );}  else {update_option($up_opt, 'false' );}
                            }
                        }
                        
                        
                     }
                }

             // Start Uplaoding

            $files = array();
            $errors = array();
                 
           foreach ($options as $key => $value) {
                
                if($value['type'] == 'upload' ){
                
                $uploaddir = WP_CONTENT_DIR . '/church_uploads/' ;
                $loc = WP_CONTENT_URL .'/church_uploads/';
                
                if(!is_dir($uploaddir)){
                    mkdir($uploaddir,0755);
                }
                
                // Error Tracking - Dir was not created
                if (!is_dir($uploaddir)) {
                        $error = array('name' => '', 'error' => 'folder_not_created');
                        $errors[] = $error;   
                }
                else 
                {
                $dir = opendir($uploaddir);
                $id = $value['id'];

                  if(isset($_FILES['attachement_'.$id]) && !empty($_FILES['attachement_'.$id]['name'])) 
                  {
                      if(eregi('image/', $_FILES['attachement_'.$id]['type']))
                      {
                        $files = array();
                        while($file = readdir($dir)) { if ($file != "." && $file != "..") { array_push($files,$file); }} closedir($dir);
                        
                        $name = $_FILES['attachement_'.$id]['name'];
                        $file_name = substr($name,0,strpos($name,'.'));
                        $file_name = str_replace(' ','_',$file_name);
                         
                        $_FILES['attachement_'.$id]['name'] = $loc . ceil(count($files) + 1).'-'. $file_name .''.strrchr($name, '.');
                        $uploadfile = $uploaddir . basename($_FILES['attachement_'.$id]['name']);
                    
                         if(move_uploaded_file($_FILES['attachement_'.$id]['tmp_name'], $uploadfile)) {
                                  update_option($id,$_FILES['attachement_'.$id]['name']);
                          }
                        }
                        else {
                            $error = array('name' => $_FILES['attachement_'.$id]['name'], 'error' => 'invalid_file');
                            $errors[] = $error;
                        }
                      }
                    }
                  } 
                }
                //Error Tracking - Files not a Image
                update_option('church_upload_errors',$errors);
                
                //Create, Encrypt and Update the Saved Settings
                global $wpdb;
                $query = "SELECT * FROM $wpdb->options WHERE option_name LIKE 'church_%' AND NOT option_name = 'church_template' AND NOT option_name = 'church_custom_template' AND NOT option_name = 'church_settings_encode'";
                $results = $wpdb->get_results($query);
                
                $output = "<ul>";
                foreach ($results as $result){
                        $output .= '<li><strong>' . $result->option_name . '</strong> - ' . $result->option_value . '</li>';
                }
                $output .= "</ul>";
                $output = base64_encode($output);
                update_option('church_settings_encode',$output);
                //End

                $send = $_GET['page'];
                header("Location: admin.php?page=$send&saved=true");                                
            
            die;

        } else if ( 'reset' == $_REQUEST['action'] ) {
            global $wpdb;
            $query = "DELETE FROM $wpdb->options WHERE option_name LIKE 'church_%'";
            $wpdb->query($query);
            
            $send = $_GET['page'];
            header("Location: admin.php?page=$send&reset=true");
            die;
        }

    }

// Check all the Options, then if the no options are created for a ralitive sub-page... it's not created.
    if(function_exists(add_object_page))
    {
        add_object_page ('Page Title', 'Theme Options', 8,'churchthemes_home', 'churchthemes_page_gen', 'http://www.imithemes.com/favicon.png');
    }
    else
    {
        add_menu_page ('Page Title', 'Theme Options', 8,'churchthemes_home', 'churchthemes_page_gen', 'http://www.churchthemes.com/favicon.png'); 
    }

         if ($page_advertising){ add_submenu_page('churchthemes_home', $themename, 'Advertising', 8, 'churchthemes_advertising', 'churchthemes_advertising'); }
         if ($page_nav){ add_submenu_page('churchthemes_home', $themename, 'Navigation', 8, 'churchthemes_nav', 'churchthemes_nav'); }
         if ($page_resizing){  add_submenu_page('churchthemes_home', $themename, 'Image Resizing', 8, 'churchthemes_image', 'churchthemes_image'); }
 
    }

 


function churchthemes_advertising(){ churchthemes_page_gen('advertising'); }
function churchthemes_nav(){ churchthemes_page_gen('nav'); }
function churchthemes_image(){ churchthemes_page_gen('image'); }

function churchthemes_page_gen($page){
 
    $options =  get_option('church_template');      
    $themename =  get_option('church_themename');      
    $shortname =  get_option('church_shortname');
    $manualurl =  get_option('church_manual'); 
    
    //Version in Backend Head
    $theme_data = get_theme_data(TEMPLATEPATH . '/style.css');
    $local_version = $theme_data['Version'];
    $update_message = '<span class="update">v.'. $local_version .'</span>';
?>
</strong>
<?php
// END
?>
<div class="wrap" id="church_options">
    <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post"  enctype="multipart/form-data">
        <div id="scrollme"><p class="submit"><input name="save" type="submit" value="Save All Changes" /></p></div>
        
        <h2>Options <?php echo $update_message; ?></h2>

        
        <?php if ( $_REQUEST['saved'] ) { ?><div style="clear:both;height:20px;"></div><div class="happy"><?php echo $themename; ?>'s Options has been updated!</div><?php } ?>
        <?php if ( $_REQUEST['reset'] ) { ?><div style="clear:both;height:20px;"></div><div class="warning"><?php echo $themename; ?>'s Options has been reset!</div><?php } ?>    
                    
        <?php //Errors
        $upload_errors = get_option('church_upload_errors');
        if(!empty($upload_errors)){
        echo '<div style="clear:both;height:20px;"></div><div class="errors"><ul>' . "\n";
            $error_shown == false;
            foreach($upload_errors as $error)
            {
                 if($error['error'] == 'folder_not_created' && $error_shown != true){
                      echo '<li><strong>Oh No!</strong> We don\' have the permissions to create the upload folder on your server. Please create it manually: <em>/wp-content/<strong>church_uploads</strong></em>. Thanks!</li>' . "\n";
                      $error_shown = true;
                }
                if($error['error'] == 'invalid_file' ){
                      echo '<li><strong>' . $error['name'] .'</strong> is not an image file, please try another file.</li>' . "\n";
                }
            }
        echo '</ul></div>' . "\n";
        delete_option('church_upload_errors');
        } ?>

        <div style="clear:both;height:10px;"></div>
        <?php echo churchthemes_machine($options,$page);  //The real work horse  ?>
        <div style="clear:both;"></div>
        <?php  wp_nonce_field('reset_options'); echo "\n"; ?>

        <p class="submit submit-footer">
            <input name="save" type="submit" value="Save All Changes" />
            <input type="hidden" name="action" value="save" />
        </p>
    </form>
        
    <form action="<?php echo wp_specialchars( $_SERVER['REQUEST_URI'] ) ?>" method="post">
        <p class="submit submit-footer submit-footer-reset">
        <input name="reset" type="submit" value="Reset Options" class="reset-button" onclick="return confirm('Click OK to reset. Any settings will be lost!');" />
        <input type="hidden" name="action" value="reset" />
        </p>
    </form>
<div style="clear:both;"></div>    
</div><!--wrap-->

 <?php
}

function churchthemes_machine($options,$page) {
        
    $counter = 0;
    foreach ($options as $value) {
        
        if($page != $value['page']){
        $counter = 0; //Reset the Counter once a new page settings page is selected
        }
        elseif($page == $value['page']){
        $counter++;
        $val = '';
        //Start Heading
         if ( $value['type'] != "heading" )
         {
            $output .= '<div class="option option-'. $value['type'] .'">'."\n".'<div class="option-inner">'."\n";
            $output .= '<label class="titledesc">'. $value['name'] .'</label>'."\n";
            $output .= '<div class="formcontainer">'."\n".'<div class="forminp">'."\n";
         } 
         //End Heading
        $select_value = '';                                   
        switch ( $value['type'] ) {
        case 'text':
            $val = $value['std'];
            if ( get_settings( $value['id'] ) != "") { $val = get_settings($value['id']); }
            $output .= '<input name="'. $value['id'] .'" id="'. $value['id'] .'" type="'. $value['type'] .'" value="'. $val .'" />';
        break;
        case 'select':

            $output .= '<select name="'. $value['id'] .'" id="'. $value['id'] .'">';
        
            $select_value = get_settings( $value['id']);
             
            foreach ($value['options'] as $option) {
                
                $selected = '';
                
                   if($select_value != '') {
                        if ( $select_value == $option) { $selected = ' selected="selected"';} 
                   } else {
                    if ($value['std'] == $option) { $selected = ' selected="selected"'; }
                   }
                  
                $output .= '<option'. $selected .'>';
                $output .= $option;
                $output .= '</option>';
             } 
             $output .= '</select>';

            
        break;
        case 'textarea':
            $ta_options = $value['options'];
            $ta_value = $value['std'];
            if( get_settings($value['id']) != "") { $ta_value = stripslashes(get_settings($value['id'])); }
            $output .= '<textarea name="'. $value['id'] .'" id="'. $value['id'] .'" cols="'. $ta_options['cols'] .'" rows="8">'.$ta_value.'</textarea>';
            
        break;
        case "radio":
            
             $select_value = get_settings( $value['id']);
                   
             foreach ($value['options'] as $key => $option) 
             { 

                 $checked = '';
                   if($select_value != '') {
                        if ( $select_value == $key) { $checked = ' checked'; } 
                   } else {
                    if ($value['std'] == $key) { $checked = ' checked'; }
                   }
                $output .= '<input type="radio" name="'. $value['id'] .'" value="'. $key .'" '. $checked .' />' . $option .'<br />';
            
            }
             
        break;
        case "checkbox": 
        
           $std = $value['std'];  
           
           $saved_std = get_option($value['id']);
           
           $checked = '';
            
            if(!empty($saved_std)) {
                if($saved_std == 'true') {
                $checked = 'checked="checked"';
                }
                else{
                   $checked = '';
                }
            }
            elseif( $std == 'true') {
               $checked = 'checked="checked"';
            }
            else {
                $checked = '';
            }

            $output .= '<input type="checkbox" class="checkbox" name="'.  $value['id'] .'" id="'. $value['id'] .'" value="true" '. $checked .' />';

        break;
        case "multicheck":
        
            $std =  $value['std'];         
            
            foreach ($value['options'] as $key => $option) {
                                             
            $church_key = $value['id'] . '_' . $key;
            $saved_std = get_option($church_key);
                    
            if(!empty($saved_std)) 
            { 
                  if($saved_std == 'true'){
                     $checked = 'checked="checked"';  
                  } 
                  else{
                      $checked = '';     
                  }    
            } 
            elseif( $std == $key) {
               $checked = 'checked="checked"';
            }
            else {
                $checked = '';                                                                                                                                                                                                                          }
            
            $output .= '<input type="checkbox" class="checkbox" name="'. $church_key .'" id="'. $church_key .'" value="true" '. $checked .' /><label for="'. $church_key .'">'. $option .'</label><br />';
                                        
            }
            
        break;
        case "upload":
            
            $output .= churchthemes_uploader_function($value['id'],$value['std'],'options');
            
        break;
        case "heading":
            
            if($counter >= 2){
               $output .= '</div>'."\n";
            }
     
            $output .= '<div class="title">';
            $output .= '<p class="submit"><input name="save" type="submit" value="Save Changes" /><input type="hidden" name="action" value="save" /></p>';
            $output .= '<h3><span class="church-expand">+</span>'. $value['name'] .'</h3>'."\n";    
            $output .= '</div>'."\n";
            $output .= '<div class="option_content">'."\n";
        break;                                    
        } 
        
        // if TYPE is an array, formatted into smaller inputs... ie smaller values
        if ( is_array($value['type'])) {
            
            foreach($value['type'] as $array){
            
                    $id =   $array['id']; 
                    $std =   $array['std'];
                    $saved_std = get_option($id);
                    if($saved_std != $std && !empty($saved_std) ){$std = $saved_std;} 
                    $meta =   $array['meta'];
                    
                    if($array['type'] == 'text') { // Only text at this point
                         
                         $output .= '<input class="input-text-small" name="'. $id .'" id="'. $id .'" type="text" value="'. $std .'" />';  
                         $output .= '<span class="meta-two">'.$meta.'</span>';
                    }
                }
        }
        
        if ( $value['type'] != "heading" ) { 
            if ( $value['type'] != "checkbox" ) 
                { 
                $output .= '<br/>';
                }
                
            $output .= '</div><div class="desc">'. $value['desc'] .'</div></div>'."\n";
            $output .= '</div></div><div class="clear"></div>'."\n";
        
            }
        }
    }
    
    $output .= '</div>';
    return $output;
    
}

// churchThemes Uploader
function churchthemes_uploader_function($id,$std){

    $uploader .= '<input type="file" name="attachement_'.$id.'" class="upload_input"></input>';
    $uploader .= '<span class="submit"><input name="save" type="submit" value="Upload" class="button upload_save" /></span>';
    $uploader .= '<input type="hidden" name="attachement_loos_'.$id.'" value="' . $globals['attachement_'.$id] .'"></input>';

    $upload = get_option($id);
    
    $uploader .= '<div class="clear"></div>';
    if (empty($upload) || $upload == $std)
    {
    $uploader .= '<input class="upload-input-text" name="'.$id.'" value="'.$std.'"/>';
    }
    else
    {
    $uploader .= '<input class="upload-input-text" name="'.$id.'" value="'.$upload.'"/>';
    $uploader .= '<div class="clear"></div>';
    $uploader .= '<a href="'. $upload . '">';
    $uploader .= '<img src="'.get_bloginfo('template_url').'/thumb.php?src='.$upload.'&w=290&h=200&zc=1" alt="" />';
    $uploader .= '</a>'; 
    }
return $uploader;
}

function wf_admin_head() { 
?>
<script type="text/javascript">
    jQuery(document).ready(function(){

        try {
        
        var timer = null;  
        var offset = jQuery('#scrollme').offset().top;
          
        jQuery(document).scroll(function(e){
            clearTimeout(timer);
            timer = setTimeout(function(){
                jQuery('#scrollme').animate({
                    top: jQuery(document).scrollTop() + offset 
                }, 'fast');
            }, 200);
        });
          
        } catch(exception) {
          // #scrollme is not on page load.
        }
        
        jQuery('#church_options .title h3').parent().next('.option_content').slideUp();
        
        var initChar;
        jQuery('#church_options .title h3').hover(function(){
            initChar = jQuery(this).children('span').html();
            if (jQuery(this).parent().next('.option_content').css('display') == 'none'){  
                jQuery(this).children('span').html("&darr;");
            }
            else
            {
               jQuery(this).children('span').html("&uarr;");  
            }
        }
        ,function(){
            jQuery(this).children('span').html(initChar)  
        })   
  
        jQuery('#church_options .title h3').click(function(){
            if (jQuery(this).parent().next('.option_content').css('display') == 'none'){
             jQuery(this).children('span').html("+");
             initChar = "-"; 
            }
            else{
            jQuery(this).children('span').html("-");
            initChar = "+";   
            
            }
            
            jQuery(this).parent().next('.option_content').slideToggle('slow');
        });
    });
</script>

<?php }

add_action('admin_head', 'wf_admin_head');    
?>