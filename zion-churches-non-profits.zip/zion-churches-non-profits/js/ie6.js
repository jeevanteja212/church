DD_belatedPNG.fix("img, .location");
